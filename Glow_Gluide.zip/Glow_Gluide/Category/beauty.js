// بيانات المنتجات
const products = [

//الكونسيلر
    {
        id: "Bp1",
        productSection: "Consealer",
        brand: "NARS",
        name: "Radiant Creamy Concealer",
        undertone: "Warm",
        color: "Ginger - Medium 2",
        image: "",
        link: "https://www.sephora.me/sa-en/p/radiant-creamy-concealer/P1281016?productVariantId=262318"
    },
    {
        id: "Bp2",
        productSection: "Consealer",
        brand: " Tarte",
        name: "Tarte Shape Tape Concealer",
        undertone: "warm",
        color: "Medium Honey",
        image: '/glow-gluide/Category/BIMG/TarteConcealer.jpg',
        link: "https://www.sephora.me/sa-en/p/shape-tape-concealer/P3643138?productVariantId=451690"
    },
    {
        id: "Bp3",
        productSection: "Consealer",
        brand: "Make Up For Ever",
        name: "ULTRA HD CONCEALER",
        undertone: " Neutral",
        color: " 31 - Macadamia",
        image: "",
        link: "https://www.sephora.me/sa-en/p/ultra-hd-concealer/467804?productVariantId=467805"
    },
    {
        id: "Bp4",
        productSection: "Consealer",
        brand: "Maybelline",
        name: "Concealer Instant Anti Age Applicator",
        undertone: " Cool",
        color: "Cool Ivory",
        image: "",
        link: "https://www.amazon.sa/-/en/Maybelline-Concealer-Instant-Anti-Age-Applicator/dp/B07PDM4MJR?th=1"
    },
    {
        id: "Bp5",
        productSection: "Consealer",
        brand: "Tarte",
        name: "Shape Tape Concealer",
        undertone: " Cool ",
        color: " Fair Beige",
        image: "",
        link: "https://www.sephora.me/sa-en/p/shape-tape-concealer/451699?productVariantId=451686"
    },
    {
        id: "Bp6",
        productSection: "Consealer",
        brand: "Maybelline",
        name: "Maybelline Instant Age Rewind Concealer",
        undertone: " Neutral ",
        color: " Neutraliser 06",
        image: "",
        link: "https://www.amazon.sa/-/en/MAYBELLINE-Instant-Eye-Concealer-Concealer-Blendable/dp/B06Y442VV3/ref=asc_df_B01JQ1T1E4/?tag=sashogostdde-21&linkCode=df0&hvadid=703903537849&hvpos=&hvnetw=g&hvrand=4274930396589826652&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9196469&hvtargid=pla-439642720041&mcid=8b10b17c00453098adee9ff5864322cd&gad_source=1&th=1"
    },
    {
        id: "Bp7",
        productSection: "Consealer",
        brand: "Fenty Beauty",
        name: "Fenty Beauty Pro Filt'r Instant Retouch Concealer",
        undertone: " Neutral",
        color: "Light Medium 230W",
        image: "",
        link: "https://www.sephora.me/sa-en/p/we-re-even-concealer/693288?productVariantId=693296"
    },




// البلشر
    {
        id: "Bp8",
        productSection: "Blush",
        brand: "Rare Beauty",
        name: "Rare Beauty Soft Pinch Liquid Blush",
        undertone: "Warm ",
        color: " Love",
        image: "",
        link: "https://www.sephora.me/sa-en/p/soft-pinch-liquid-blush/P10017094?productVariantId=527978"
    },
    {
        id: "Bp9",
        productSection: "Blush",
        brand: "SEPHORA COLLECTION",
        name: "Colorful Blush 06 Fascinated",
        undertone: " Neutral",
        color: "06 Fascinated (Soft pink suitable for neutral undertones)",
        image: "",
        link: "https://www.amazon.sa/dp/B0B3KHBWTY"
    },
    {
        id: "Bp10",
        productSection: "Blush",
        brand: "NARS",
        name: "Blush in Orgasm",
        undertone: " Neutral",
        color: "Orgasm (Peachy pink with shimmer, complements neutral undertones)",
        image: "",
        link: "https://www.narscosmetics.sa/en/mini-blush/024516996728.html?gad_source=1&gclid=EAIaIQobChMI1fnyxpr0iwMVGpGDBx06Ti_0EAQYDyABEgJFJ_D_BwE"
    },
    {
        id: "Bp11",
        productSection: "Blush",
        brand: "Fenty Beauty",
        name: "Cheeks Out Freestyle Cream Blush",
        undertone: " Neutral",
        color: " Strawberry Drip ",
        image: "",
        link: "https://www.sephora.me/sa-en/p/cheeks-out-freestyle-cream-blush/510663?productVariantId=510658"
    },
    {
        id: "Bp12",
        productSection: "Blush",
        brand: "MAC",
        name: "Powder Blush",
        undertone: " Warm",
        color: " Gingerly",
        image: "",
        link: "https://en-saudi.ounass.com/shop-mac-cosmetics-gingerly-powder-blush-6g-for-women-214362519_8594.html"
    },
    {
        id: "Bp13",
        productSection: "Blush",
        brand: "Clinique",
        name: "Cheek Pop Powder Blush",
        undertone: "cool",
        color: " Pansy Pop ",
        image: "",
        link: "https://www.clinique.com/product/1593/29770/makeup/blushers/cheek-poptm-powder-blush?shade=Pansy_Pop"
    },
    {
        id: "Bp14",
        productSection: "Blush",
        brand: "Benefit",
        name: "Benefit Cosmetics Box o' Powder Blush",
        undertone: "cool",
        color: "Dandelion",
        image: "",
        link: "https://www.sephora.me/sa-en/p/dandelion/586007?gad_source=1&gclid=EAIaIQobChMIn5Lpw7X7iwMVMKiDBx10ch3mEAQYAiABEgIvrvD_BwE&gclsrc=aw.ds"
    },
    {
        id: "Bp15",
        productSection: "Blush",
        brand: "Milani",
        name: "Milani Baked Blush",
        undertone: "cool",
        color: "Luminoso",
        image: "",
        link: "https://www.amazon.sa/-/en/Milani-Baked-Blush-Cruelty-Free-Highlight/dp/B00518N2JC/ref=asc_df_B00518N2JC/?tag=sashogostdde-21&linkCode=df0&hvadid=703879783387&hvpos=&hvnetw=g&hvrand=15468527454680010042&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9196469&hvtargid=pla-462682944884&mcid=04ca3f1c3be83c8cb682e05ba5c2b535&gad_source=1&th=1"
    },


//الارواج
    {
        id: "Bp16",
        productSection: "Lipstick",
        brand: "DIOR",
        name: "Rouge Dior",
        undertone: "Warm ",
        color: " 080 Red Smile",
        image: "",
        link: "https://www.sephora.me/sa-en/p/rouge-dior/P10056323?productVariantId=718788"
    },
    {
        id: "Bp17",
        productSection: "Lipstick",
        brand: "MAC",
        name: "Matte Lipstick",
        undertone: " Neutral",
        color: "Velvet Teddy ",
        image: "",
        link: "https://www.namshi.com/saudi-en/ZCF8DED795A25901AEC1EZ/p?utm_source=google&utm_medium=cpc&utm_content=&utm_campaign=d1377_sa_web_ar_perf_google_pmax_open_perception_na_na&gad_source=1&gclid=EAIaIQobChMIzYTbna_0iwMVs4lQBh2EPgzNEAQYBSABEgJCXfD_BwE"
    },
    {
        id: "Bp18",
        productSection: "Lipstick",
        brand: "Fenty Beauty",
        name: "Fenty Beauty Gloss Bomb Heat",
        undertone: "Warm ",
        color: "Hot Chocolit ",
        image: "",
        link: "https://www.sephora.me/sa-en/p/gloss-bomb-heat-lip-luminzer-plumper/P10017314?productVariantId=556047"
    },
    {
        id: "Bp19",
        productSection: "Lipstick",
        brand: "Urban Decay",
        name: "Vice Lip Bond Glossy Liquid Lipstick",
        undertone: "Cool ",
        color: "OG Backtalk: Mauve Nude Pink ",
        image: "",
        link: "https://www.sephora.me/sa-en/p/vice-lip-bond-glossy-liquid-lipstick/706669?productVariantId=706670"
    },
    {
        id: "Bp20",
        productSection: "Lipstick",
        brand: "Fenty Beauty",
        name: "Gloss Bomb Universal Lip Luminizer",
        undertone: " Cool",
        color: " Fu$$y ",
        image: "",
        link: "https://fentybeauty.com/en-sa/products/gloss-bomb-universal-lip-luminizer-fuy?variant=35110472712237"
    },
    {
        id: "Bp21",
        productSection: "Lipstick",
        brand: "Huda Beauty",
        name: "Liquid Matte Ultra-Comfort Transfer-proof Lipstick",
        undertone: "Neutral",
        color: " Bombshell ",
        image: "",
        link: "https://www.sephora.me/sa-en/p/liquid-matte-ultra-comfort-transfer-proof-lipstick/578009?productVariantId=578012"
    },


//الفاوندشن
    {
        id: "Bp22",
        productSection: "Foundation",
        brand: "Too Faced",
        name: "Born This Way Foundation",
        undertone: "Warm ",
        color: " Warm Beige",
        image: "",
        link: "https://www.sephora.me/sa-en/p/born-this-way-foundation-undetectable-coverage/P2248001?productVariantId=337064"
    },
    {
        id: "Bp23",
        productSection: "Foundation",
        brand: "NARS",
        name: "Natural Radiant Longwear Foundation",
        undertone: "Cool ",
        color: "Mont Blanc",
        image: "",
        link: "https://www.sephora.me/sa-en/p/natural-radiant-longwear-foundation/P3250032?productVariantId=429553"
    },

    {
        id: "Bp24",
        productSection: "Foundation",
        brand: "SEPHORA COLLECTION",
        name: "Best Skin Ever Liquid Foundation 15.5N",
        undertone: " Neutral",
        color: "15.5N (Light skin with neutral undertone)",
        image: "",
        link: "https://www.amazon.com/SEPHORA-COLLECTION-Liquid-Foundation-Unisex/dp/B0BG9Z57JV"
    },

    {
        id: "Bp25",
        productSection: "Foundation",
        brand: "SEPHORA COLLECTION",
        name: "Best Skin Ever Liquid Foundation 34.5N",
        undertone: " Neutral",
        color: " 34.5N (Medium skin with neutral undertone)",
        image: "",
        link: "https://www.noon.com/uae-ar/sephora-collection-best-skin-ever-liquid-foundation-34-5-n-for-medium-skin-with-neutral-undertones-25ml/Z5244EA2AF92DDDCC0950Z/p/"
    },

    {
        id: "Bp26",
        productSection: "Foundation",
        brand: "Fenty Beauty",
        name: "Pro Filt'r Soft Matte Longwear Foundation",
        undertone: " Warm",
        color: " 290 - NEUTRAL OLIVE ",
        image: "",
        link: "https://www.sephora.me/sa-en/p/pro-filt-r-soft-matte-longwear-foundation/614651?productVariantId=398347"
    },

    {
        id: "Bp27",
        productSection: "Foundation",
        brand: "MAC",
        name: "Studio Fix Fluid Foundation",
        undertone: " Cool",
        color: "NC15 (Light skin with cool undertone)",
        image: "",
        link: "https://www.maccosmetics-sa.com/product/13847/120613/studio-fix-fluid-spf-15-24hr-matte-foundation-oil-control?shade=NC15"
    },

    {
        id: "Bp28",
        productSection: "Foundation",
        brand: "Estee Lauder",
        name: "Double Wear - Stay-in-Place Foundation",
        undertone: "Cool ",
        color: "Sand (Light-medium skin with cool undertone)",
        image: "",
        link: "https://www.sephora.me/sa-en/p/double-wear-stay-in-place-foundation-spf-10/404926?productVariantId=258827"
    },


//الباودر
    {
        id: "Bp29",
        productSection: "Powder",
        brand: "SEPHORA COLLECTION",
        name: "Best Skin Ever Matte Powder Foundation 44N",
        undertone: " Neutral",
        color: "44N (Medium skin with neutral undertone) ",
        image: "",
        link: "https://shrouqnay.com/en/sephora-best-skin-ever-matte-powder-foundation-75gm-44n/p861477375"
    },
    {
        id: "Bp30",
        productSection: "Powder",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp31",
        productSection: "Powder",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp32",
        productSection: "Powder",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp33",
        productSection: "Powder",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp34",
        productSection: "Powder",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },


//المناكير
    {
        id: "Bp35",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp36",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    
    {
        id: "Bp37",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    
    {
        id: "Bp38",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp39",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp40",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp41",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp42",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp43",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp44",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp45",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp46",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp47",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp48",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp49",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp50",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp51",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp52",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp53",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: "",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp54",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    {
        id: "Bp56",
        productSection: "NailPolish",
        brand: "",
        name: "",
        undertone: " Neutral",
        color: "",
        image: "",
        link: ""
    },
    
    
    
    ];


    function getFavorites() {
    return JSON.parse(localStorage.getItem("favorites")) || [];
}

// تحديث حالة المفضلة في التخزين المحلي
function saveFavorites(favorites) {
    localStorage.setItem("favorites", JSON.stringify(favorites));
}

// توليد المنتجات ديناميكيًا داخل الأقسام
function generateProducts() {
    products.forEach(product => {
        const container = document.getElementById(product.productSection);
        if (container) {
            container.innerHTML += `
                <div class="product ${product.undertone.toLowerCase()}" id="${product.id}">
                    <div class="product-image">
                        <img src="${product.image}" alt="${product.name}">
                        <button class="favorite-btn" data-id="${product.id}">
                            <i class='bx bxs-heart'></i>
                        </button>
                    </div>
                    <span class="brand">${product.brand}</span>
                    <h4>${product.name}</h4>
                    <span class="undertone">Undertone: ${product.undertone}</span>
                    <span class="color">Material & Color: ${product.color}</span>
                    <a href="${product.link}" target="_blank">
                        <button class="view-btn">View Product</button>
                    </a>
                </div>
            `;
        }
    });

    // استدعاء تشغيل زر المفضلة بعد إضافة المنتجات
    setupFavoriteButtons();
}

// تشغيل زر المفضلة وتخزين البيانات
function setupFavoriteButtons() {
    let favorites = getFavorites();
    
    document.querySelectorAll(".favorite-btn").forEach(button => {
        const productId = button.getAttribute("data-id");

        // تفعيل الزر إذا كان المنتج في المفضلة
        if (favorites.includes(productId)) {
            button.classList.add("active");
        }

        button.addEventListener("click", function() {
            if (favorites.includes(productId)) {
                favorites = favorites.filter(id => id !== productId);
                this.classList.remove("active");
            } else {
                favorites.push(productId);
                this.classList.add("active");
            }

            saveFavorites(favorites);
        });
    });
}

// تحريك السلايدر
function moveSlider(productSectionId, direction) {
    const container = document.getElementById(productSectionId);
    const scrollAmount = 270; 

    container.scrollBy({
        left: direction * scrollAmount,
        behavior: 'smooth'
    });
}

// تحميل المنتجات عند فتح الصفحة
document.addEventListener("DOMContentLoaded", generateProducts);




//فلتر الاندرتون 
function openFilter() {
    document.getElementById("filterSidebar").classList.add("open");
}

function closeFilter() {
    document.getElementById("filterSidebar").classList.remove("open");
}

function toggleDropdown(id) {
    const dropdown = document.getElementById(id);
    dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
}

/* فلتر الااندرتون */
function applyFilter() {
    const undertones = [...document.querySelectorAll(".undertone:checked")].map(e => e.value.toLowerCase());
    const products = document.querySelectorAll(".product");

    let isFiltered = false;
    products.forEach(product => {
        product.style.display = "none";

        const hasMatchingUndertone = undertones.length === 0 || undertones.some(tone => product.classList.contains(tone));

        if (hasMatchingUndertone) {
            product.style.display = "block";
            isFiltered = true;
        }
    });

    const messageElement = document.getElementById('filterMessage');
    if (!isFiltered) {
        messageElement.textContent = "لا توجد نتائج مطابقة للفلاتر التي اخترتها.";
    } else {
        messageElement.textContent = "";
    }
}

function moveSlider(sliderId, direction) {
    let slider = document.getElementById(sliderId);
    let scrollAmount = 270;

    slider.style.transition = "transform 0.3s ease";
    slider.scrollBy({
        left: direction * scrollAmount,
        behavior: "smooth"
    });
}