document.addEventListener('DOMContentLoaded', function() {
    const loginContainer = document.querySelector('.container');
    const signupContainer = document.querySelector('#signup-container');
    const logoutBtnContainer = document.querySelector('.logout-btn-container');

    const loginLink = document.querySelector('.signup-link');
    const signupLink = document.querySelector('.login-link');
    
    const logoutBtn = document.querySelector('.logout-btn');

    // إظهار صفحة تسجيل الدخول
    loginContainer.classList.add('active');
    
    // عند الضغط على رابط "إنشاء حساب"
    loginLink.addEventListener('click', function(event) {
        event.preventDefault();
        loginContainer.classList.remove('active');
        signupContainer.classList.add('active');
    });
    
    // عند الضغط على رابط "تسجيل الدخول"
    signupLink.addEventListener('click', function(event) {
        event.preventDefault();
        signupContainer.classList.remove('active');
        loginContainer.classList.add('active');
    });

    // عند الضغط على زر "تسجيل الخروج"
    logoutBtn.addEventListener('click', function() {
        logoutBtnContainer.classList.remove('active');
        loginContainer.classList.add('active');
    });

    // التحقق من تطابق كلمة المرور مع تأكيد كلمة المرور
    const passwordInput = document.getElementById("password-signup");  // تحديث id هنا
    const confirmPasswordInput = document.getElementById("confirm-password");  // تحديث id هنا
    const errorMessage = document.getElementById("password-error");

    confirmPasswordInput.addEventListener('input', function() {
        if (passwordInput.value !== confirmPasswordInput.value) {
            errorMessage.textContent = "Passwords do not match!";
            errorMessage.style.visibility = "visible"; // عرض رسالة الخطأ
            confirmPasswordInput.classList.add("invalid"); // إضافة تنسيق غير صالح
        } else {
            errorMessage.style.visibility = "hidden"; // إخفاء رسالة الخطأ إذا كانت كلمات المرور متطابقة
            confirmPasswordInput.classList.remove("invalid"); // إزالة التنسيق غير الصالح
        }
    });
});